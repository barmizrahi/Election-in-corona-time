package id316554260_id316080365;

public class CitizenIsNotASoldier extends Exception{
	
	public CitizenIsNotASoldier(String str) {
		super(str);
	}
	

}
