package id316554260_id316080365;

public class CitizenAgeIsLessThen18 extends Exception {
	
	public CitizenAgeIsLessThen18(String str) {
		super(str);
	}
}
