package id316554260_id316080365;

public class CitizenIDOutOfRnage extends Exception {

	
	public CitizenIDOutOfRnage(String str) {
		super(str);
	}
	
	
	
	
}
