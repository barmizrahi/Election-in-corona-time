package id316554260_id316080365;

public interface Sickable {
	boolean setHowManyDaysInIsolation(int days);
	void setIsIsolated(boolean isIsolated2);
}
