package Model;

public class CitizenAgeIsLessThen18 extends Exception {
	
	public CitizenAgeIsLessThen18(String str) {
		super(str);
	}
}
