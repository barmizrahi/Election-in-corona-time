package Model;

public class CitizenIDOutOfRnage extends Exception {

	
	public CitizenIDOutOfRnage(String str) {
		super(str);
	}
	
	
	
	
}
