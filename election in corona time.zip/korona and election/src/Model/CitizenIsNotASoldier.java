package Model;

public class CitizenIsNotASoldier extends Exception{
	
	public CitizenIsNotASoldier(String str) {
		super(str);
	}
	

}
