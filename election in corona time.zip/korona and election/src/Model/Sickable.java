package Model;

public interface Sickable {
	boolean setHowManyDaysInIsolation(int days);
	void setIsIsolated(boolean isIsolated2);
}
