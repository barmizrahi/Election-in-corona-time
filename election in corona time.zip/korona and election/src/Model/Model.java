package Model;

public class Model {
	private Elections election;
	
	
	public Model (Elections e) {
		this.election=e;
	}


	public Elections getElection() {
		return election;
	}

	
	
	
	
	
	
	
	
}
